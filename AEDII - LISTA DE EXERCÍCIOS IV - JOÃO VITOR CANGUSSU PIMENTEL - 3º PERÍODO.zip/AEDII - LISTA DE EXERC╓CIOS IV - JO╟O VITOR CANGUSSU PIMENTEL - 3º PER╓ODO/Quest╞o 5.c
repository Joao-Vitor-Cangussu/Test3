#include <stdio.h>

double soma(double a, double b) {
    return a + b;
}

double subtracao(double a, double b) {
    return a - b;
}

double multiplicacao(double a, double b) {
    return a * b;
}

double divisao(double a, double b) {
    if (b != 0) {
        return a / b;
    } else {
        printf("Erro: Divisão por zero!\n");
        return 0;
    }
}

int main() {
    double num1, num2;
    char operacao;

    printf("Digite o primeiro numero: ");
    scanf("%lf", &num1);
    printf("Digite o segundo numero: ");
    scanf("%lf", &num2);
    printf("Digite a operacao (+, -, *, /): ");
    scanf(" %c", &operacao);

    double resultado;
    switch (operacao) {
        case '+':
            resultado = soma(num1, num2);
            break;
        case '-':
            resultado = subtracao(num1, num2);
            break;
        case '*':
            resultado = multiplicacao(num1, num2);
            break;
        case '/':
            resultado = divisao(num1, num2);
            break;
        default:
            printf("Operacao invalida!\n");
            return 1;
    }

    printf("O resultado de %.2lf %c %.2lf e: %.2lf\n", num1, operacao, num2, resultado);

    return 0;
}