#include <stdio.h>

#define SIZE 150

int somaArray(int array[], int tamanho) {
    int soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += array[i];
    }
    return soma;
}

int main() {
    int numeros[SIZE];

    printf("Digite 150 numeros:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("Número %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    int soma = somaArray(numeros, SIZE);

    printf("A soma dos elementos do array e: %d\n", soma);

    return 0;
}