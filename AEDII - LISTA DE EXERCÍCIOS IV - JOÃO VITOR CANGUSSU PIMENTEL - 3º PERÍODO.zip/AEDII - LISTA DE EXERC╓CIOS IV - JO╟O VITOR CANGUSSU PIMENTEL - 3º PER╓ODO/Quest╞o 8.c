#include <stdio.h>
#include <string.h>

struct Produto {
    int codigo;
    char descricao[100];
    float preco;
};

void buscarProduto(const struct Produto produtos[], int codigo, char descricao[], float *preco) {
    for (int i = 0; i < 10; i++) {
        if (produtos[i].codigo == codigo) {
            strcpy(descricao, produtos[i].descricao);
            *preco = produtos[i].preco;
            return;
        }
    }
    strcpy(descricao, "Produto não encontrado");
    *preco = 0.0;
}

int main() {
    struct Produto produtos[10];

    for (int i = 0; i < 10; i++) {
        printf("Digite o código do produto %d: ", i + 1);
        scanf("%d", &produtos[i].codigo);

        printf("Digite a descrição do produto %d: ", i + 1);
        scanf("%s", produtos[i].descricao);

        printf("Digite o preço do produto %d: ", i + 1);
        scanf("%f", &produtos[i].preco);
    }

    int codigo;
    printf("\nDigite o código do produto que deseja buscar: ");
    scanf("%d", &codigo);

    char descricao[100];
    float preco;
    buscarProduto(produtos, codigo, descricao, &preco);
    printf("\nInformações do produto:\n");
    printf("Descrição: %s\n", descricao);
    printf("Preço: R$ %.2f\n", preco);

    return 0;
}