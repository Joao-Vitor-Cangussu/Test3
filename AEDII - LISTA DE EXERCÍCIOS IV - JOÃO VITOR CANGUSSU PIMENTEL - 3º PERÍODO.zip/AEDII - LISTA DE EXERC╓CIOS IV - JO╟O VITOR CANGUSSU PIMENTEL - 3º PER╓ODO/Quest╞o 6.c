#include <stdio.h>
#include <string.h>

struct Livro {
    char titulo[100];
    char autor[100];
    int ano;
};

void alteraLivro(struct Livro *livro, const char *novoTitulo, const char *novoAutor, int novoAno) {
    strcpy(livro->titulo, novoTitulo);
    strcpy(livro->autor, novoAutor);
    livro->ano = novoAno;
}

int main() {

    struct Livro meuLivro;

    alteraLivro(&meuLivro, "O Senhor dos Anéis", "J.R.R. Tolkien", 1954);

    printf("Título: %s\n", meuLivro.titulo);
    printf("Autor: %s\n", meuLivro.autor);
    printf("Ano: %d\n", meuLivro.ano);

    return 0;
}
