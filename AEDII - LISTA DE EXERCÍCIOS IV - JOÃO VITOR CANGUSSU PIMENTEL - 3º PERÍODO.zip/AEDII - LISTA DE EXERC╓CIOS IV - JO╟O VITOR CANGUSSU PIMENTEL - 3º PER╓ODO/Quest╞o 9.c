#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Filme {
    char titulo[100];
    char diretor[100];
    int ano_de_lancamento;
};

int compararFilmes(const void *a, const void *b) {
    return strcmp(((struct Filme *)a)->titulo, ((struct Filme *)b)->titulo);
}

int main() {

    struct Filme filmes[3];

    for (int i = 0; i < 3; i++) {
        printf("Digite o titulo do filme %d: ", i + 1);
        scanf("%s", filmes[i].titulo);

        printf("Digite o diretor do filme %d: ", i + 1);
        scanf("%s", filmes[i].diretor);

        printf("Digite o ano de lançamento do filme %d: ", i + 1);
        scanf("%d", &filmes[i].ano_de_lancamento);
    }

    qsort(filmes, 3, sizeof(struct Filme), compararFilmes);

    printf("\nFilmes em ordem alfabetica pelo titulo:\n");
    for (int i = 0; i < 3; i++) {
        printf("Titulo: %s\n", filmes[i].titulo);
        printf("Diretor: %s\n", filmes[i].diretor);
        printf("Ano de lançamento: %d\n\n", filmes[i].ano_de_lancamento);
    }

    return 0;
}
