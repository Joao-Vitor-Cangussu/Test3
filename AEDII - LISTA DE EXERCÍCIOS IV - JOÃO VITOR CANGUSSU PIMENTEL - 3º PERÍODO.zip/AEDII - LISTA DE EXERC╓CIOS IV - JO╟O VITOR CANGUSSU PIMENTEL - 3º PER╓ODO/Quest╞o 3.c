#include <stdio.h>

int main() {
    int variavel = 10;
    int *ponteiro;
    
    printf("Valor da variavel: %d\n", variavel);

    ponteiro = &variavel;

    *ponteiro = 20;

    printf("Valor da variavel depois da alteracao: %d\n", variavel);

    return 0;
}