#include <stdio.h>
#include <string.h>

struct Aluno {
    char nome[100];
    int matricula;
    float media;
};

int main() {

    struct Aluno alunos[5];

    printf("Digite os dados dos 5 alunos:\n");
    for (int i = 0; i < 5; i++) {
        printf("\nAluno %d:\n", i + 1);

        printf("Nome: ");
        fgets(alunos[i].nome, sizeof(alunos[i].nome), stdin);
        alunos[i].nome[strcspn(alunos[i].nome, "\n")] = '\0';

        printf("Matricula: ");
        scanf("%d", &alunos[i].matricula);

        printf("Media: ");
        scanf("%f", &alunos[i].media);

        while (getchar() != '\n');
    }

    printf("\nAlunos com media maior ou igual a 7.0:\n");
    for (int i = 0; i < 5; i++) {
        if (alunos[i].media >= 7.0) {
            printf("\nAluno %d:\n", i + 1);
            printf("Nome: %s\n", alunos[i].nome);
            printf("Matricula: %d\n", alunos[i].matricula);
            printf("Media: %.2f\n", alunos[i].media);
        }
    }

    return 0;
}