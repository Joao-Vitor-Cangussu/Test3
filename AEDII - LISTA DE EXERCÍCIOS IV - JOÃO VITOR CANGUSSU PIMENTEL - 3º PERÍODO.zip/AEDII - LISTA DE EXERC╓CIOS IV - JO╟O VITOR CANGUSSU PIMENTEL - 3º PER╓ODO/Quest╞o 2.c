#include <stdio.h>

int maiorNumero(int num1, int num2, int num3) {
    int maior = num1;
    if (num2 > maior) {
        maior = num2;
    }
    if (num3 > maior) {
        maior = num3;
    }
    return maior;
}

int main() {
    int num1, num2, num3;

    printf("Informe o primeiro numero: ");
    scanf("%d", &num1);

    printf("Informe o segundo numero: ");
    scanf("%d", &num2);

    printf("Informe o terceiro numero: ");
    scanf("%d", &num3);

    int maior = maiorNumero(num1, num2, num3);
    printf("O maior numero e: %d\n", maior);

    return 0;
}